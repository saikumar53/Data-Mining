Required Packages to run the file
1. pandas
2. numpy
3. matplotlib
4. seaborn
5. sys
6. sklearn

Run the code
1. The code is written in python jupyter notebook.
2. To run the code, just replace the variable 'file' with the file name in the notebook
    example : file = 'pca_demo.txt'
3. Click the run button in the jupyter notebook or 'Shift + enter'.

Results
1. Three plots will be generated based on PCA, SVD and t-SNE decompositions.
